package com.springBeanScope;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class EmployeeConfig {

	@Bean(name="employee")
	@Scope("prototype")
	public Employee getEmployee() {
		 return new Employee(125,"Sham",60000);
	}
}
