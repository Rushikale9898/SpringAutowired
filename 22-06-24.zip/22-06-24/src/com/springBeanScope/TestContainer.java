package com.springBeanScope;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestContainer {

	public static void main(String[] args) {
		
		ApplicationContext context=new AnnotationConfigApplicationContext(EmployeeConfig.class);
		
		Employee emp1=(Employee)context.getBean("employee");
		
		System.out.println(emp1.hashCode());
		
		Employee emp2=(Employee)context.getBean("employee");
		System.out.println(emp2.hashCode());

	}

}
