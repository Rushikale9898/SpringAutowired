package com.springBeanCollaborationJavaConfig;

import org.springframework.beans.factory.annotation.Autowired;

public class Student {

	private int studentId;
	private String studentName;
	private String studentAdress;
 
	@Autowired
	private Department department;

	public Student() {

	}

	public Student(int studentId, String studentName, String studentAdress, Department department) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentAdress = studentAdress;
		this.department = department;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", studentAdress=" + studentAdress
				+ ", department=" + department + "]";
	}

}
