package com.springBeanCollaborationJavaConfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class StudentConfig {

	@Bean(name="department")
	public Department getDepartment() {
		return new Department(124,"Computer Science");
}
	@Bean(name="student")
	public Student getStudent() {
		return new Student(110,"Ram","Pune",new Department());
	}
}
