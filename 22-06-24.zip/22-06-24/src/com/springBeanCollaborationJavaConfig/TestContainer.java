package com.springBeanCollaborationJavaConfig;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestContainer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ApplicationContext context=new AnnotationConfigApplicationContext(StudentConfig.class);
		
		Student student= (Student)context.getBean("student");
		
		System.out.println(student.toString());
	}

}
